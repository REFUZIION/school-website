<!DOCTYPE html>
<html>
<head>
    <title>Uitgang</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<center><h1>Gefeliciteerd! U heeft het einde behaald.</h1></center>
<div id=uitgang></div>
<a href="http://u533473.gluweb.nl/" target="_blank">klik hier om naar mijn website te gaan</a>
</body>
</html>
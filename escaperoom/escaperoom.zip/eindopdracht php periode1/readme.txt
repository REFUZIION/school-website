Dit is een uitleg over de escape room, voor u (de docent).

Ik heb ingesteld dat de admin code(admin123) gebruikt kan worden op alle velden. Alleen op kamer 4 kan de code niet ingevuld worden.
De 6 cijferige code voor kamer 4 is '128394', dit zijn 6 cijfers die in kamer 1 t/m 3 zichtbaar zijn.